/* ***********************************************************
 * This file was automatically generated on 2020-05-19.      *
 *                                                           *
 * C/C++ Bindings Version 2.1.29                             *
 *                                                           *
 * If you have a bugfix for this file and want to commit it, *
 * please fix the bug in the generator. You can find a link  *
 * to the generators git repository on tinkerforge.com       *
 *************************************************************/

#ifndef BRICKLET_LASER_RANGE_FINDER_V2_H
#define BRICKLET_LASER_RANGE_FINDER_V2_H

#include "ip_connection.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * \defgroup BrickletLaserRangeFinderV2 Laser Range Finder Bricklet 2.0
 */

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Measures distance up to 40m with laser light
 */
typedef Device LaserRangeFinderV2;

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_GET_DISTANCE 1

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_SET_DISTANCE_CALLBACK_CONFIGURATION 2

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_GET_DISTANCE_CALLBACK_CONFIGURATION 3

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_GET_VELOCITY 5

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_SET_VELOCITY_CALLBACK_CONFIGURATION 6

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_GET_VELOCITY_CALLBACK_CONFIGURATION 7

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_SET_ENABLE 9

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_GET_ENABLE 10

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_SET_CONFIGURATION 11

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_GET_CONFIGURATION 12

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_SET_MOVING_AVERAGE 13

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_GET_MOVING_AVERAGE 14

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_SET_OFFSET_CALIBRATION 15

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_GET_OFFSET_CALIBRATION 16

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_SET_DISTANCE_LED_CONFIG 17

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_GET_DISTANCE_LED_CONFIG 18

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_GET_SPITFP_ERROR_COUNT 234

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_SET_BOOTLOADER_MODE 235

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_GET_BOOTLOADER_MODE 236

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_SET_WRITE_FIRMWARE_POINTER 237

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_WRITE_FIRMWARE 238

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_SET_STATUS_LED_CONFIG 239

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_GET_STATUS_LED_CONFIG 240

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_GET_CHIP_TEMPERATURE 242

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_RESET 243

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_WRITE_UID 248

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_READ_UID 249

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_FUNCTION_GET_IDENTITY 255

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Signature: \code void callback(int16_t distance, void *user_data) \endcode
 * 
 * This callback is triggered periodically according to the configuration set by
 * {@link laser_range_finder_v2_set_distance_callback_configuration}.
 * 
 * The parameter is the same as {@link laser_range_finder_v2_get_distance}.
 */
#define LASER_RANGE_FINDER_V2_CALLBACK_DISTANCE 4

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Signature: \code void callback(int16_t velocity, void *user_data) \endcode
 * 
 * This callback is triggered periodically according to the configuration set by
 * {@link laser_range_finder_v2_set_velocity_callback_configuration}.
 * 
 * The parameter is the same as {@link laser_range_finder_v2_get_velocity}.
 */
#define LASER_RANGE_FINDER_V2_CALLBACK_VELOCITY 8


/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_THRESHOLD_OPTION_OFF 'x'

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_THRESHOLD_OPTION_OUTSIDE 'o'

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_THRESHOLD_OPTION_INSIDE 'i'

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_THRESHOLD_OPTION_SMALLER '<'

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_THRESHOLD_OPTION_GREATER '>'

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_DISTANCE_LED_CONFIG_OFF 0

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_DISTANCE_LED_CONFIG_ON 1

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_DISTANCE_LED_CONFIG_SHOW_HEARTBEAT 2

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_DISTANCE_LED_CONFIG_SHOW_DISTANCE 3

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_BOOTLOADER_MODE_BOOTLOADER 0

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_BOOTLOADER_MODE_FIRMWARE 1

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_BOOTLOADER_MODE_BOOTLOADER_WAIT_FOR_REBOOT 2

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_BOOTLOADER_MODE_FIRMWARE_WAIT_FOR_REBOOT 3

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_BOOTLOADER_MODE_FIRMWARE_WAIT_FOR_ERASE_AND_REBOOT 4

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_BOOTLOADER_STATUS_OK 0

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_BOOTLOADER_STATUS_INVALID_MODE 1

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_BOOTLOADER_STATUS_NO_CHANGE 2

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_BOOTLOADER_STATUS_ENTRY_FUNCTION_NOT_PRESENT 3

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_BOOTLOADER_STATUS_DEVICE_IDENTIFIER_INCORRECT 4

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_BOOTLOADER_STATUS_CRC_MISMATCH 5

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_STATUS_LED_CONFIG_OFF 0

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_STATUS_LED_CONFIG_ON 1

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_STATUS_LED_CONFIG_SHOW_HEARTBEAT 2

/**
 * \ingroup BrickletLaserRangeFinderV2
 */
#define LASER_RANGE_FINDER_V2_STATUS_LED_CONFIG_SHOW_STATUS 3

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * This constant is used to identify a Laser Range Finder Bricklet 2.0.
 *
 * The {@link laser_range_finder_v2_get_identity} function and the
 * {@link IPCON_CALLBACK_ENUMERATE} callback of the IP Connection have a
 * \c device_identifier parameter to specify the Brick's or Bricklet's type.
 */
#define LASER_RANGE_FINDER_V2_DEVICE_IDENTIFIER 2144

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * This constant represents the display name of a Laser Range Finder Bricklet 2.0.
 */
#define LASER_RANGE_FINDER_V2_DEVICE_DISPLAY_NAME "Laser Range Finder Bricklet 2.0"

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Creates the device object \c laser_range_finder_v2 with the unique device ID \c uid and adds
 * it to the IPConnection \c ipcon.
 */
void laser_range_finder_v2_create(LaserRangeFinderV2 *laser_range_finder_v2, const char *uid, IPConnection *ipcon);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Removes the device object \c laser_range_finder_v2 from its IPConnection and destroys it.
 * The device object cannot be used anymore afterwards.
 */
void laser_range_finder_v2_destroy(LaserRangeFinderV2 *laser_range_finder_v2);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Returns the response expected flag for the function specified by the
 * \c function_id parameter. It is *true* if the function is expected to
 * send a response, *false* otherwise.
 *
 * For getter functions this is enabled by default and cannot be disabled,
 * because those functions will always send a response. For callback
 * configuration functions it is enabled by default too, but can be disabled
 * via the laser_range_finder_v2_set_response_expected function. For setter functions it is
 * disabled by default and can be enabled.
 *
 * Enabling the response expected flag for a setter function allows to
 * detect timeouts and other error conditions calls of this setter as well.
 * The device will then send a response for this purpose. If this flag is
 * disabled for a setter function then no response is sent and errors are
 * silently ignored, because they cannot be detected.
 */
int laser_range_finder_v2_get_response_expected(LaserRangeFinderV2 *laser_range_finder_v2, uint8_t function_id, bool *ret_response_expected);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Changes the response expected flag of the function specified by the
 * \c function_id parameter. This flag can only be changed for setter
 * (default value: *false*) and callback configuration functions
 * (default value: *true*). For getter functions it is always enabled.
 *
 * Enabling the response expected flag for a setter function allows to detect
 * timeouts and other error conditions calls of this setter as well. The device
 * will then send a response for this purpose. If this flag is disabled for a
 * setter function then no response is sent and errors are silently ignored,
 * because they cannot be detected.
 */
int laser_range_finder_v2_set_response_expected(LaserRangeFinderV2 *laser_range_finder_v2, uint8_t function_id, bool response_expected);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Changes the response expected flag for all setter and callback configuration
 * functions of this device at once.
 */
int laser_range_finder_v2_set_response_expected_all(LaserRangeFinderV2 *laser_range_finder_v2, bool response_expected);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Registers the given \c function with the given \c callback_id. The
 * \c user_data will be passed as the last parameter to the \c function.
 */
void laser_range_finder_v2_register_callback(LaserRangeFinderV2 *laser_range_finder_v2, int16_t callback_id, void (*function)(void), void *user_data);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Returns the API version (major, minor, release) of the bindings for this
 * device.
 */
int laser_range_finder_v2_get_api_version(LaserRangeFinderV2 *laser_range_finder_v2, uint8_t ret_api_version[3]);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Returns the measured distance.
 * 
 * The laser has to be enabled, see {@link laser_range_finder_v2_set_enable}.
 * 
 * 
 * If you want to get the value periodically, it is recommended to use the
 * {@link LASER_RANGE_FINDER_V2_CALLBACK_DISTANCE} callback. You can set the callback configuration
 * with {@link laser_range_finder_v2_set_distance_callback_configuration}.
 */
int laser_range_finder_v2_get_distance(LaserRangeFinderV2 *laser_range_finder_v2, int16_t *ret_distance);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * The period is the period with which the {@link LASER_RANGE_FINDER_V2_CALLBACK_DISTANCE} callback is triggered
 * periodically. A value of 0 turns the callback off.
 * 
 * If the `value has to change`-parameter is set to true, the callback is only
 * triggered after the value has changed. If the value didn't change
 * within the period, the callback is triggered immediately on change.
 * 
 * If it is set to false, the callback is continuously triggered with the period,
 * independent of the value.
 * 
 * It is furthermore possible to constrain the callback with thresholds.
 * 
 * The `option`-parameter together with min/max sets a threshold for the {@link LASER_RANGE_FINDER_V2_CALLBACK_DISTANCE} callback.
 * 
 * The following options are possible:
 * 
 * \verbatim
 *  "Option", "Description"
 * 
 *  "'x'",    "Threshold is turned off"
 *  "'o'",    "Threshold is triggered when the value is *outside* the min and max values"
 *  "'i'",    "Threshold is triggered when the value is *inside* or equal to the min and max values"
 *  "'<'",    "Threshold is triggered when the value is smaller than the min value (max is ignored)"
 *  "'>'",    "Threshold is triggered when the value is greater than the min value (max is ignored)"
 * \endverbatim
 * 
 * If the option is set to 'x' (threshold turned off) the callback is triggered with the fixed period.
 */
int laser_range_finder_v2_set_distance_callback_configuration(LaserRangeFinderV2 *laser_range_finder_v2, uint32_t period, bool value_has_to_change, char option, int16_t min, int16_t max);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Returns the callback configuration as set by {@link laser_range_finder_v2_set_distance_callback_configuration}.
 */
int laser_range_finder_v2_get_distance_callback_configuration(LaserRangeFinderV2 *laser_range_finder_v2, uint32_t *ret_period, bool *ret_value_has_to_change, char *ret_option, int16_t *ret_min, int16_t *ret_max);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Returns the measured velocity. The value has a range of -12800 to 12700
 * and is given in 1/100 m/s.
 * 
 * The velocity measurement only produces stables results if a fixed
 * measurement rate (see {@link laser_range_finder_v2_set_configuration}) is configured. Also the laser
 * has to be enabled, see {@link laser_range_finder_v2_set_enable}.
 * 
 * 
 * If you want to get the value periodically, it is recommended to use the
 * {@link LASER_RANGE_FINDER_V2_CALLBACK_VELOCITY} callback. You can set the callback configuration
 * with {@link laser_range_finder_v2_set_velocity_callback_configuration}.
 */
int laser_range_finder_v2_get_velocity(LaserRangeFinderV2 *laser_range_finder_v2, int16_t *ret_velocity);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * The period is the period with which the {@link LASER_RANGE_FINDER_V2_CALLBACK_VELOCITY} callback is triggered
 * periodically. A value of 0 turns the callback off.
 * 
 * If the `value has to change`-parameter is set to true, the callback is only
 * triggered after the value has changed. If the value didn't change
 * within the period, the callback is triggered immediately on change.
 * 
 * If it is set to false, the callback is continuously triggered with the period,
 * independent of the value.
 * 
 * It is furthermore possible to constrain the callback with thresholds.
 * 
 * The `option`-parameter together with min/max sets a threshold for the {@link LASER_RANGE_FINDER_V2_CALLBACK_VELOCITY} callback.
 * 
 * The following options are possible:
 * 
 * \verbatim
 *  "Option", "Description"
 * 
 *  "'x'",    "Threshold is turned off"
 *  "'o'",    "Threshold is triggered when the value is *outside* the min and max values"
 *  "'i'",    "Threshold is triggered when the value is *inside* or equal to the min and max values"
 *  "'<'",    "Threshold is triggered when the value is smaller than the min value (max is ignored)"
 *  "'>'",    "Threshold is triggered when the value is greater than the min value (max is ignored)"
 * \endverbatim
 * 
 * If the option is set to 'x' (threshold turned off) the callback is triggered with the fixed period.
 */
int laser_range_finder_v2_set_velocity_callback_configuration(LaserRangeFinderV2 *laser_range_finder_v2, uint32_t period, bool value_has_to_change, char option, int16_t min, int16_t max);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Returns the callback configuration as set by {@link laser_range_finder_v2_set_velocity_callback_configuration}.
 */
int laser_range_finder_v2_get_velocity_callback_configuration(LaserRangeFinderV2 *laser_range_finder_v2, uint32_t *ret_period, bool *ret_value_has_to_change, char *ret_option, int16_t *ret_min, int16_t *ret_max);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Enables the laser of the LIDAR if set to *true*.
 * 
 * We recommend that you wait 250ms after enabling the laser before
 * the first call of {@link laser_range_finder_v2_get_distance} to ensure stable measurements.
 */
int laser_range_finder_v2_set_enable(LaserRangeFinderV2 *laser_range_finder_v2, bool enable);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Returns the value as set by {@link laser_range_finder_v2_set_enable}.
 */
int laser_range_finder_v2_get_enable(LaserRangeFinderV2 *laser_range_finder_v2, bool *ret_enable);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * The **Acquisition Count** defines the number of times the Laser Range Finder Bricklet
 * will integrate acquisitions to find a correlation record peak. With a higher count,
 * the Bricklet can measure longer distances. With a lower count, the rate increases. The
 * allowed values are 1-255.
 * 
 * If you set **Enable Quick Termination** to true, the distance measurement will be terminated
 * early if a high peak was already detected. This means that a higher measurement rate can be achieved
 * and long distances can be measured at the same time. However, the chance of false-positive
 * distance measurements increases.
 * 
 * Normally the distance is calculated with a detection algorithm that uses peak value,
 * signal strength and noise. You can however also define a fixed **Threshold Value**.
 * Set this to a low value if you want to measure the distance to something that has
 * very little reflection (e.g. glass) and set it to a high value if you want to measure
 * the distance to something with a very high reflection (e.g. mirror). Set this to 0 to
 * use the default algorithm. The other allowed values are 1-255.
 * 
 * Set the **Measurement Frequency** to force a fixed measurement rate. If set to 0,
 * the Laser Range Finder Bricklet will use the optimal frequency according to the other
 * configurations and the actual measured distance. Since the rate is not fixed in this case,
 * the velocity measurement is not stable. For a stable velocity measurement you should
 * set a fixed measurement frequency. The lower the frequency, the higher is the resolution
 * of the calculated velocity. The allowed values are 10Hz-500Hz (and 0 to turn the fixed
 * frequency off).
 * 
 * The default values for Acquisition Count, Enable Quick Termination, Threshold Value and
 * Measurement Frequency are 128, false, 0 and 0.
 */
int laser_range_finder_v2_set_configuration(LaserRangeFinderV2 *laser_range_finder_v2, uint8_t acquisition_count, bool enable_quick_termination, uint8_t threshold_value, uint16_t measurement_frequency);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Returns the configuration as set by {@link laser_range_finder_v2_set_configuration}.
 */
int laser_range_finder_v2_get_configuration(LaserRangeFinderV2 *laser_range_finder_v2, uint8_t *ret_acquisition_count, bool *ret_enable_quick_termination, uint8_t *ret_threshold_value, uint16_t *ret_measurement_frequency);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Sets the length of a `moving averaging <https://en.wikipedia.org/wiki/Moving_average>`__
 * for the distance and velocity.
 * 
 * Setting the length to 0 will turn the averaging completely off. With less
 * averaging, there is more noise on the data.
 */
int laser_range_finder_v2_set_moving_average(LaserRangeFinderV2 *laser_range_finder_v2, uint8_t distance_average_length, uint8_t velocity_average_length);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Returns the length moving average as set by {@link laser_range_finder_v2_set_moving_average}.
 */
int laser_range_finder_v2_get_moving_average(LaserRangeFinderV2 *laser_range_finder_v2, uint8_t *ret_distance_average_length, uint8_t *ret_velocity_average_length);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * The offset is added to the measured distance.
 * It is saved in non-volatile memory, you only have to set it once.
 * 
 * The Bricklet comes with a per-sensor factory-calibrated offset value,
 * you should not have to call this function.
 * 
 * If you want to re-calibrate the offset you first have to set it to 0.
 * Calculate the offset by measuring the distance to a known distance
 * and set it again.
 */
int laser_range_finder_v2_set_offset_calibration(LaserRangeFinderV2 *laser_range_finder_v2, int16_t offset);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Returns the offset value as set by {@link laser_range_finder_v2_set_offset_calibration}.
 */
int laser_range_finder_v2_get_offset_calibration(LaserRangeFinderV2 *laser_range_finder_v2, int16_t *ret_offset);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Configures the distance LED to be either turned off, turned on, blink in
 * heartbeat mode or show the distance (brighter = object is nearer).
 */
int laser_range_finder_v2_set_distance_led_config(LaserRangeFinderV2 *laser_range_finder_v2, uint8_t config);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Returns the LED configuration as set by {@link laser_range_finder_v2_set_distance_led_config}
 */
int laser_range_finder_v2_get_distance_led_config(LaserRangeFinderV2 *laser_range_finder_v2, uint8_t *ret_config);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Returns the error count for the communication between Brick and Bricklet.
 * 
 * The errors are divided into
 * 
 * * ACK checksum errors,
 * * message checksum errors,
 * * framing errors and
 * * overflow errors.
 * 
 * The errors counts are for errors that occur on the Bricklet side. All
 * Bricks have a similar function that returns the errors on the Brick side.
 */
int laser_range_finder_v2_get_spitfp_error_count(LaserRangeFinderV2 *laser_range_finder_v2, uint32_t *ret_error_count_ack_checksum, uint32_t *ret_error_count_message_checksum, uint32_t *ret_error_count_frame, uint32_t *ret_error_count_overflow);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Sets the bootloader mode and returns the status after the requested
 * mode change was instigated.
 * 
 * You can change from bootloader mode to firmware mode and vice versa. A change
 * from bootloader mode to firmware mode will only take place if the entry function,
 * device identifier and CRC are present and correct.
 * 
 * This function is used by Brick Viewer during flashing. It should not be
 * necessary to call it in a normal user program.
 */
int laser_range_finder_v2_set_bootloader_mode(LaserRangeFinderV2 *laser_range_finder_v2, uint8_t mode, uint8_t *ret_status);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Returns the current bootloader mode, see {@link laser_range_finder_v2_set_bootloader_mode}.
 */
int laser_range_finder_v2_get_bootloader_mode(LaserRangeFinderV2 *laser_range_finder_v2, uint8_t *ret_mode);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Sets the firmware pointer for {@link laser_range_finder_v2_write_firmware}. The pointer has
 * to be increased by chunks of size 64. The data is written to flash
 * every 4 chunks (which equals to one page of size 256).
 * 
 * This function is used by Brick Viewer during flashing. It should not be
 * necessary to call it in a normal user program.
 */
int laser_range_finder_v2_set_write_firmware_pointer(LaserRangeFinderV2 *laser_range_finder_v2, uint32_t pointer);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Writes 64 Bytes of firmware at the position as written by
 * {@link laser_range_finder_v2_set_write_firmware_pointer} before. The firmware is written
 * to flash every 4 chunks.
 * 
 * You can only write firmware in bootloader mode.
 * 
 * This function is used by Brick Viewer during flashing. It should not be
 * necessary to call it in a normal user program.
 */
int laser_range_finder_v2_write_firmware(LaserRangeFinderV2 *laser_range_finder_v2, uint8_t data[64], uint8_t *ret_status);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Sets the status LED configuration. By default the LED shows
 * communication traffic between Brick and Bricklet, it flickers once
 * for every 10 received data packets.
 * 
 * You can also turn the LED permanently on/off or show a heartbeat.
 * 
 * If the Bricklet is in bootloader mode, the LED is will show heartbeat by default.
 */
int laser_range_finder_v2_set_status_led_config(LaserRangeFinderV2 *laser_range_finder_v2, uint8_t config);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Returns the configuration as set by {@link laser_range_finder_v2_set_status_led_config}
 */
int laser_range_finder_v2_get_status_led_config(LaserRangeFinderV2 *laser_range_finder_v2, uint8_t *ret_config);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Returns the temperature as measured inside the microcontroller. The
 * value returned is not the ambient temperature!
 * 
 * The temperature is only proportional to the real temperature and it has bad
 * accuracy. Practically it is only useful as an indicator for
 * temperature changes.
 */
int laser_range_finder_v2_get_chip_temperature(LaserRangeFinderV2 *laser_range_finder_v2, int16_t *ret_temperature);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Calling this function will reset the Bricklet. All configurations
 * will be lost.
 * 
 * After a reset you have to create new device objects,
 * calling functions on the existing ones will result in
 * undefined behavior!
 */
int laser_range_finder_v2_reset(LaserRangeFinderV2 *laser_range_finder_v2);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Writes a new UID into flash. If you want to set a new UID
 * you have to decode the Base58 encoded UID string into an
 * integer first.
 * 
 * We recommend that you use Brick Viewer to change the UID.
 */
int laser_range_finder_v2_write_uid(LaserRangeFinderV2 *laser_range_finder_v2, uint32_t uid);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Returns the current UID as an integer. Encode as
 * Base58 to get the usual string version.
 */
int laser_range_finder_v2_read_uid(LaserRangeFinderV2 *laser_range_finder_v2, uint32_t *ret_uid);

/**
 * \ingroup BrickletLaserRangeFinderV2
 *
 * Returns the UID, the UID where the Bricklet is connected to,
 * the position, the hardware and firmware version as well as the
 * device identifier.
 * 
 * The position can be 'a', 'b', 'c', 'd', 'e', 'f', 'g' or 'h' (Bricklet Port).
 * The Raspberry Pi HAT (Zero) Brick is always at position 'i' and the Bricklet
 * connected to an :ref:`Isolator Bricklet <isolator_bricklet>` is always as
 * position 'z'.
 * 
 * The device identifier numbers can be found :ref:`here <device_identifier>`.
 * |device_identifier_constant|
 */
int laser_range_finder_v2_get_identity(LaserRangeFinderV2 *laser_range_finder_v2, char ret_uid[8], char ret_connected_uid[8], char *ret_position, uint8_t ret_hardware_version[3], uint8_t ret_firmware_version[3], uint16_t *ret_device_identifier);

#ifdef __cplusplus
}
#endif

#endif
